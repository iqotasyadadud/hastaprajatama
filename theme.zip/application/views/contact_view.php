 <section id="contact-info">
        <div class="center">                
            <h2>Temukan Kami</h2>
            <p class="lead">Alamat kantor terdekat kami</p>
        </div>
        <div class="gmap-area">
            <div class="container">
                <div class="row">
                    <div class="col-sm-5 text-center">
                        <div class="gmap">
                            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3326.7976027587524!2d112.73450348227544!3d-7.437404049522303!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2dd7e6be87cb9fa3%3A0xcc9f7882a779ea74!2sPT.+HASTA+PRAJATAMA!5e0!3m2!1sen!2s!4v1509276088032" width="800" height="600" frameborder="0" style="border:0" allowfullscreen></iframe>
                        </div>
                    </div>

                    <div class="col-sm-7 map-content">
                        <ul class="row">
                            <li class="col-sm-6">
                                <address>
                                    <h5>Head Office</h5>
                                    <p>Jalan Lingkar Timur No. 1 Kemiri <br>
                                    Sidoarjo, Jawa Timur, Indonesia</p>
                                    <p>Phone: (031) 8956551 ; 8073893 <br>
                                    Email Address: hastaprajatama.fabrikator@gmail.com</p>
                                </address>

                                <address>
                                    <h5>Zonal Office</h5>
                                    <p>Jalan Ciputat Raya No. 100E <br>
                                    Kebayoran Lama, Jakarta Selatan, Indonesia</p>                                
                                    <p>Phone: (021) 72895005 <br>
                                    Email Address: hastaprajatama.fabrikator@gmail.com</p>
                                </address>
                            </li>


                            
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>  <!--/gmap_area -->

   
